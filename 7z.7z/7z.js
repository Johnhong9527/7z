#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const shell = require('shelljs');
const file_path = process.argv[2] || 1;

// console.log(path.resolve(file_path));

(async function() {
	const _is_file = await isFile(file_path);
	// 判断文件或目录路径是否正确
	if (_is_file) {
		// 压缩当前目录下所有文件
		if (file_path === '.') {
			console.log('压缩当前目录下所有文件');
			const allFiles = await fs.readdirSync(file_path);

			for (let i = 0; i < allFiles.length; i++) {
				//  忽略部分文件
				if (
					allFiles[i].search(/^\./) < 0 &&
					allFiles[i].search(/\.7z/g) < 0 &&
					allFiles[i].search(/node_modules/g) < 0 &&
					allFiles[i].search(/yarn\.lock/g) < 0 &&
					allFiles[i].search(/package\.json/g) < 0
				) {
					// 目录
					// 文件
					// shell.exec(`7z a ${allFiles[i].split('.')[0]}.7z ${allFiles[i]}`);
					// console.log(allFiles[i]);
					if (await isDirectory(allFiles[i])) {
						shell.exec(`7z a ${allFiles[i]}.7z ${allFiles[i]}`);
					} else {
						shell.exec(`7z a ${allFiles[i].split('.')[0]}.7z ${allFiles[i]}`);
					}
				}
			}
			// console.log(allFiles);
		} else {
			// 压缩输入文件
			shell.exec(`7z a ${file_path.split('.')[0]}.7z ${file_path}`);
		}
		// console.log(file_path);
	}
})();

// shell.exec(`7z a ${file_path.split('.')[0]}.7z ${file_path}`);
function isFile(filePath) {
	return new Promise((resolve, reject) => {
		fs.stat(filePath, (err, stats) => {
			if (err) reject(err);
			resolve(true);
		});
	});
}

function isDirectory(path) {
	return new Promise((resolve, reject) => {
		fs.stat(path, (err, stats) => {
			if (err) reject(err);
			resolve(stats.isDirectory());
		});
	});
}
